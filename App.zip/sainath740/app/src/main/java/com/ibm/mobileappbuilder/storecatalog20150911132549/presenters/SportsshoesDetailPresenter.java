
package com.ibm.mobileappbuilder.storecatalog20150911132549.presenters;

import com.ibm.mobileappbuilder.storecatalog20150911132549.R;
import com.ibm.mobileappbuilder.storecatalog20150911132549.ds.SportsshoesDSItem;

import ibmmobileappbuilder.ds.CrudDatasource;
import ibmmobileappbuilder.ds.Datasource;
import ibmmobileappbuilder.mvp.presenter.BasePresenter;
import ibmmobileappbuilder.mvp.presenter.DetailCrudPresenter;
import ibmmobileappbuilder.mvp.view.DetailView;

public class SportsshoesDetailPresenter extends BasePresenter implements DetailCrudPresenter<SportsshoesDSItem>,
      Datasource.Listener<SportsshoesDSItem> {

    private final CrudDatasource<SportsshoesDSItem> datasource;
    private final DetailView view;

    public SportsshoesDetailPresenter(CrudDatasource<SportsshoesDSItem> datasource, DetailView view){
        this.datasource = datasource;
        this.view = view;
    }

    @Override
    public void deleteItem(SportsshoesDSItem item) {
        datasource.deleteItem(item, this);
    }

    @Override
    public void editForm(SportsshoesDSItem item) {
        view.navigateToEditForm();
    }

    @Override
    public void onSuccess(SportsshoesDSItem item) {
                view.showMessage(R.string.item_deleted, true);
        view.close(true);
    }

    @Override
    public void onFailure(Exception e) {
        view.showMessage(R.string.error_data_generic, true);
    }
}

