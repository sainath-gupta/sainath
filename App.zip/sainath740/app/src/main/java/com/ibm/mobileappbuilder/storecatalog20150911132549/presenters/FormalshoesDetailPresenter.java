
package com.ibm.mobileappbuilder.storecatalog20150911132549.presenters;

import com.ibm.mobileappbuilder.storecatalog20150911132549.R;
import com.ibm.mobileappbuilder.storecatalog20150911132549.ds.FormalshoesDSItem;

import ibmmobileappbuilder.ds.CrudDatasource;
import ibmmobileappbuilder.ds.Datasource;
import ibmmobileappbuilder.mvp.presenter.BasePresenter;
import ibmmobileappbuilder.mvp.presenter.DetailCrudPresenter;
import ibmmobileappbuilder.mvp.view.DetailView;

public class FormalshoesDetailPresenter extends BasePresenter implements DetailCrudPresenter<FormalshoesDSItem>,
      Datasource.Listener<FormalshoesDSItem> {

    private final CrudDatasource<FormalshoesDSItem> datasource;
    private final DetailView view;

    public FormalshoesDetailPresenter(CrudDatasource<FormalshoesDSItem> datasource, DetailView view){
        this.datasource = datasource;
        this.view = view;
    }

    @Override
    public void deleteItem(FormalshoesDSItem item) {
        datasource.deleteItem(item, this);
    }

    @Override
    public void editForm(FormalshoesDSItem item) {
        view.navigateToEditForm();
    }

    @Override
    public void onSuccess(FormalshoesDSItem item) {
                view.showMessage(R.string.item_deleted, true);
        view.close(true);
    }

    @Override
    public void onFailure(Exception e) {
        view.showMessage(R.string.error_data_generic, true);
    }
}

