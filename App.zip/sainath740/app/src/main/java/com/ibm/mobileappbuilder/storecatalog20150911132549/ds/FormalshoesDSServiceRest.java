
package com.ibm.mobileappbuilder.storecatalog20150911132549.ds;
import java.util.List;
import retrofit.Callback;
import retrofit.http.GET;
import retrofit.http.Query;
import retrofit.http.POST;
import retrofit.http.Body;
import retrofit.http.DELETE;
import retrofit.http.Path;
import retrofit.http.PUT;
import retrofit.mime.TypedByteArray;
import retrofit.http.Part;
import retrofit.http.Multipart;

public interface FormalshoesDSServiceRest{

	@GET("/app/57ef50cd9d17e00300d4cb43/r/formalshoesDS")
	void queryFormalshoesDSItem(
		@Query("skip") String skip,
		@Query("limit") String limit,
		@Query("conditions") String conditions,
		@Query("sort") String sort,
		@Query("select") String select,
		@Query("populate") String populate,
		Callback<List<FormalshoesDSItem>> cb);

	@GET("/app/57ef50cd9d17e00300d4cb43/r/formalshoesDS/{id}")
	void getFormalshoesDSItemById(@Path("id") String id, Callback<FormalshoesDSItem> cb);

	@DELETE("/app/57ef50cd9d17e00300d4cb43/r/formalshoesDS/{id}")
  void deleteFormalshoesDSItemById(@Path("id") String id, Callback<FormalshoesDSItem> cb);

  @POST("/app/57ef50cd9d17e00300d4cb43/r/formalshoesDS/deleteByIds")
  void deleteByIds(@Body List<String> ids, Callback<List<FormalshoesDSItem>> cb);

  @POST("/app/57ef50cd9d17e00300d4cb43/r/formalshoesDS")
  void createFormalshoesDSItem(@Body FormalshoesDSItem item, Callback<FormalshoesDSItem> cb);

  @PUT("/app/57ef50cd9d17e00300d4cb43/r/formalshoesDS/{id}")
  void updateFormalshoesDSItem(@Path("id") String id, @Body FormalshoesDSItem item, Callback<FormalshoesDSItem> cb);

  @GET("/app/57ef50cd9d17e00300d4cb43/r/formalshoesDS")
  void distinct(
        @Query("distinct") String colName,
        @Query("conditions") String conditions,
        Callback<List<String>> cb);
    
    @Multipart
    @POST("/app/57ef50cd9d17e00300d4cb43/r/formalshoesDS")
    void createFormalshoesDSItem(
        @Part("data") FormalshoesDSItem item,
        @Part("picture") TypedByteArray picture,
        Callback<FormalshoesDSItem> cb);
    
    @Multipart
    @PUT("/app/57ef50cd9d17e00300d4cb43/r/formalshoesDS/{id}")
    void updateFormalshoesDSItem(
        @Path("id") String id,
        @Part("data") FormalshoesDSItem item,
        @Part("picture") TypedByteArray picture,
        Callback<FormalshoesDSItem> cb);
}

